
# Veigo Admin Panel

## Kurulum

1. `npm install`
2. `npm run dev`

Admin Giriş:
- E-posta: admin@veigo.de
- Şifre: admin123
