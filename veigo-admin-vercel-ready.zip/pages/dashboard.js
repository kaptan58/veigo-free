
import Head from 'next/head';

export default function Dashboard() {
  return (
    <>
      <Head>
        <title>Yönetim Paneli</title>
      </Head>
      <div className="min-h-screen p-6 bg-gray-100">
        <h1 className="text-3xl font-bold mb-4">Yönetim Paneli</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded shadow">Toplam Sürücü: 42</div>
          <div className="bg-white p-4 rounded shadow">Aktif Yolculuk: 8</div>
          <div className="bg-white p-4 rounded shadow">Günlük Gelir: €1,245</div>
        </div>
      </div>
    </>
  );
}
