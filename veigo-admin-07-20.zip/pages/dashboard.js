
export default function Dashboard() {
  return (
    <div style={{ padding: 20 }}>
      <h1 style={{ fontSize: '24px', fontWeight: 'bold' }}>Yönetici Paneli</h1>
      <div style={{ marginTop: 20 }}>
        <div>🧑‍💼 Toplam Sürücü: 42</div>
        <div>🚘 Aktif Yolculuk: 8</div>
        <div>💰 Günlük Gelir: €1,245</div>
      </div>
    </div>
  );
}
