
import Head from 'next/head';
import { useState } from 'react';
import { useRouter } from 'next/router';

export default function Home() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();

  const handleLogin = () => {
    if (email === 'admin@veigo.de' && password === 'admin123') {
      router.push('/dashboard');
    } else {
      alert('Geçersiz giriş');
    }
  };

  return (
    <>
      <Head>
        <title>Admin Giriş</title>
      </Head>
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100">
        <img src="/bolt-logo.png" alt="Bolt Logo" className="w-20 h-20 mb-4" />
        <h1 className="text-2xl font-bold mb-4">Admin Giriş</h1>
        <input
          type="email"
          placeholder="E-posta"
          className="mb-2 px-4 py-2 border rounded"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="Şifre"
          className="mb-4 px-4 py-2 border rounded"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button onClick={handleLogin} className="bg-blue-600 text-white px-4 py-2 rounded">
          Giriş Yap
        </button>
      </div>
    </>
  );
}
