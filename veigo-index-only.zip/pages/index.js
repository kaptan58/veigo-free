
export default function Home() {
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100vh',
      fontFamily: 'Arial, sans-serif'
    }}>
      <h1>Veigo Admin Giriş</h1>
      <input type="email" placeholder="E-posta" style={{ padding: 10, marginBottom: 10, borderRadius: 5, border: '1px solid #ccc' }} />
      <input type="password" placeholder="Şifre" style={{ padding: 10, marginBottom: 10, borderRadius: 5, border: '1px solid #ccc' }} />
      <button style={{ padding: 10, backgroundColor: '#0070f3', color: '#fff', border: 'none', borderRadius: 5 }}>
        Giriş Yap
      </button>
    </div>
  )
}
